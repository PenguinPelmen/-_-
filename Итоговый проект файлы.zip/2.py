from nltk.stem.snowball import SnowballStemmer
from nltk.corpus import stopwords
import pandas as pd
import re
from sklearn.metrics import accuracy_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv('train.csv', sep='\t')
df.loc[df.Score == 'Positive', 'Score'] = 1
df.loc[df.Score == 'Negative', 'Score'] = 0
train_recals, test_recals, train_scores, test_scores = train_test_split(df['Text'], df['Score'], test_size=0.25)

train_scores = train_scores.astype('int')
test_scores = test_scores.astype('int')

stop_words = set(stopwords.words('russian'))


def df_preprocess(text):
    reg = re.compile('[^а-яА-Яa-zA-Z0-9 ]')
    text = text.lower().replace('ё', 'е')
    text = text.replace('ъ', 'ь')
    text = text.replace('й', 'и')
    text = reg.sub(' ', text)

    stemmer = SnowballStemmer('russian')
    text = ' '.join([stemmer.stem(word) for word in text.split() if word not in stop_words])

    return text


train_recals = train_recals.apply(df_preprocess)
test_recals = test_recals.apply(df_preprocess)
tvectorizer = TfidfVectorizer()
train_recals_tfidf = tvectorizer.fit_transform(train_recals)
test_recals_tfidf = tvectorizer.transform(test_recals)

clf = LogisticRegression(random_state=0).fit(train_recals_tfidf, train_scores)
predict = clf.predict(test_recals_tfidf)
print(accuracy_score(predict, test_scores))
